<html>
<head>
<title>Ejemplo de php</title>
</head>
<body style="font-family:Calibri">
Aqui escribir� su HTML normal.
<BR><BR>
<?php
echo "Parte de PHP<br>";
for($i=0;$i<10;$i++)
{
 echo "Linea ".$i."<br>";
}
?>
</body>
</html>