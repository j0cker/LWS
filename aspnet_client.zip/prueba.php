<?PHP
 echo "prueba1";

?>